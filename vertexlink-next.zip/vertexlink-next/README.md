# VertexLink — Agence Web Prestige v2.0
## Next.js 14 · Tailwind CSS · Framer Motion

> **Objectif** : Égaliser le niveau de [Pulsor Agency](https://pulsor.agency) avec un thème High-Tech Light exclusif.

---

## 🚀 Installation rapide

```bash
# 1. Installer les dépendances
npm install

# 2. Lancer le dev server
npm run dev

# 3. Build de production
npm run build && npm start
```

---

## 🗂 Architecture du projet

```
src/
├── app/
│   ├── layout.tsx              # Root layout — fonts, metadata, cursor, progress bar
│   ├── globals.css             # Design tokens CSS, animations, syntax highlighting
│   ├── page.tsx                # Home page
│   ├── services/
│   │   └── page.tsx            # Page Services
│   ├── realisations/
│   │   └── page.tsx            # ★ Page Réalisations (livrée)
│   └── contact/
│       └── page.tsx            # Page Contact
│
├── components/
│   ├── Navbar.tsx              # Navigation glassmorphism
│   ├── MetricsBand.tsx         # Bandeau métriques agence
│   ├── FilterBar.tsx           # Filtres animés (layout pill FM)
│   ├── ProjectCard.tsx         # Carte projet complète
│   └── ui/
│       └── ProgressBar.tsx     # Barre scroll + curseur custom
│
└── data/
    └── projects.ts             # Source de vérité — projets typés
```

---

## 🎨 Design System — High-Tech Light

### Couleurs
| Token | Valeur | Usage |
|-------|--------|-------|
| `pearl-100` | `#f8f9fc` | Fond principal nacré |
| `pearl-50`  | `#ffffff` | Cartes, panels |
| `blue`      | `#2563eb` | Accent primaire électrique |
| `violet`    | `#7c3aed` | Accent secondaire électrique |
| `cyan`      | `#06b6d4` | Accent tertiaire, annotations code |
| `ink`       | `#0d0f1a` | Texte principal |
| `ink-3`     | `#7c7f9a` | Meta, labels, commentaires |

### Typographie
```
Syne 800     → Titres massifs (hero, h1, h2)  font-syne
Fira Code    → DNA technique, labels, code     font-fira
DM Sans 300  → Corps de texte, descriptions   font-dm
```

### Animations Framer Motion
| Composant | Animation |
|-----------|-----------|
| `ProjectCard` | Entrée staggerée (index × 120ms), hover lift −6px |
| `FilterBar`   | Layout pill partagé (`layoutId="filter-pill"`) |
| `Navbar`      | Slide-down depuis le haut au chargement |
| `MetricsBand` | Fade-up staggeré à l'entrée viewport |
| `ScoreBar`    | `scaleX` 0→1 déclenché par `useInView` |
| `Hero`        | Parallaxe scroll (`useScroll + useTransform`) |
| `CodeSnippet` | Slide-up depuis le bas au hover |
| `ProgressBar` | `useSpring` sur `scrollYProgress` |

---

## 🧩 Ajouter un projet

Dans `src/data/projects.ts`, ajouter un objet à `PROJECTS` :

```ts
{
  id:            "mon-projet",
  number:        "// 06",
  category:      "vitrine",         // vitrine | landing | saas | refonte
  categoryLabel: "Site Vitrine",
  size:          "standard",        // hero | wide | full | tall | standard
  title:         "Mon Projet",
  client:        "Nom du client",
  excerpt:       "Description...",
  url:           "monprojet.fr",
  year:          2025,
  accentColor:   "blue",            // blue | violet | cyan
  stack: [
    { label: "HTML5", variant: "blue" },
    // ...
  ],
  scores: [
    { label: "Performance", value: 98, type: "perf" },
    // ...
  ],
  codeSnippet: [
    `<span class="code-cm">// Mon commentaire</span>`,
    // ...5 lignes max
  ],
  mockupTheme: "blue",              // blue | violet | cyan | amber
}
```

---

## ⚡ Performance

- **next/font** : zéro layout shift garanti
- **`optimizePackageImports`** : bundle Framer Motion optimisé
- **`useInView`** : animations déclenchées seulement au viewport (pas de overhead)
- **`AnimatePresence mode="popLayout"`** : transitions fluides sur filtre
- **Images** : AVIF/WebP auto via `next/image`
- **Headers sécurité** : CSP, X-Frame, nosniff configurés

---

## 📋 Pages à créer (structure modulaire)

| Page | Status |
|------|--------|
| `/` Home | À créer |
| `/services` | À créer |
| `/realisations` | ✅ **Livré** |
| `/contact` | À créer |
| `/realisations/[id]` | À créer (page projet détaillée) |

---

## 📩 Contact

**vertexlink33@gmail.com** · Instagram **@vertexlink_**

*Code 100% sur mesure. No WordPress. No Wix.*
