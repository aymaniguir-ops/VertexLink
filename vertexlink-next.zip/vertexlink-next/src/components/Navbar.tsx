"use client";

/**
 * VertexLink — Navbar Component
 *
 * Navigation principale :
 *  - Glassmorphism (backdrop-blur + fond nacré semi-transparent)
 *  - Liens avec numéros de ligne style éditeur de code
 *  - Active state détecté via usePathname (Next.js)
 *  - CTA "Réserver un appel" avec gradient
 *  - Framer Motion : entrée depuis le haut
 */

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import clsx from "clsx";

const NAV_LINKS = [
  { href: "/",             label: "Home",        ln: "01" },
  { href: "/services",     label: "Services",    ln: "02" },
  { href: "/realisations", label: "Réalisations",ln: "03" },
  { href: "/contact",      label: "Contact",     ln: "04" },
] as const;

export function Navbar() {
  const pathname = usePathname();

  return (
    <motion.nav
      initial={{ opacity: 0, y: -16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className={clsx(
        "fixed top-0 left-0 right-0 z-50 h-[60px]",
        "flex items-center justify-between px-10",
        "bg-pearl-100/85 backdrop-blur-xl border-b border-black/6"
      )}
      role="navigation"
      aria-label="Navigation principale"
    >
      {/* ── Brand ── */}
      <Link href="/" className="flex items-center gap-2.5 group no-underline">
        {/* Logo mark */}
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue to-violet flex items-center justify-center shadow-[0_2px_10px_rgba(37,99,235,.28)] group-hover:shadow-blue-glow transition-shadow duration-300">
          <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
            <path d="M4 4h5v5H4zM11 4h5v5h-5zM4 11h5v5H4zM13.5 11v8M9.5 15h8"
                  stroke="white" strokeWidth="1.7" strokeLinecap="round" />
          </svg>
        </div>
        {/* Wordmark */}
        <span className="font-syne font-extrabold text-[15px] tracking-tight text-ink">
          VertexLink
        </span>
        {/* Version tag */}
        <span className="font-fira text-[9px] text-blue border border-blue/ring bg-blue/glow px-1.5 py-0.5 rounded">
          v2.0
        </span>
      </Link>

      {/* ── Links ── */}
      <ul className="hidden md:flex items-center gap-0.5 list-none" role="list">
        {NAV_LINKS.map(({ href, label, ln }) => {
          const isActive = pathname === href || (href !== "/" && pathname.startsWith(href));
          return (
            <li key={href}>
              <Link
                href={href}
                className={clsx(
                  "relative flex items-center gap-1 font-fira text-[11px] px-3.5 py-1.5 rounded-lg",
                  "transition-all duration-200 no-underline",
                  isActive
                    ? "text-blue bg-blue/glow border border-blue/ring"
                    : "text-ink-3 hover:text-ink hover:bg-pearl-200"
                )}
                aria-current={isActive ? "page" : undefined}
              >
                {/* Line number */}
                <span className="text-[8px] text-ink-4 leading-none select-none">{ln}</span>
                {label}
                {/* Active underline dot */}
                {isActive && (
                  <motion.span
                    layoutId="nav-dot"
                    className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-blue"
                  />
                )}
              </Link>
            </li>
          );
        })}
      </ul>

      {/* ── CTA ── */}
      <Link
        href="/contact"
        className={clsx(
          "hidden md:flex items-center gap-2",
          "font-syne font-bold text-[12px] text-white",
          "px-4 py-2 rounded-xl no-underline",
          "bg-gradient-to-r from-blue to-violet",
          "shadow-[0_2px_14px_rgba(37,99,235,.28)]",
          "hover:shadow-blue-glow hover:-translate-y-0.5",
          "transition-all duration-200"
        )}
      >
        Réserver un appel
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
          <path d="M1 6h10M6 1l5 5-5 5" stroke="white" strokeWidth="1.5"
                strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </Link>
    </motion.nav>
  );
}
