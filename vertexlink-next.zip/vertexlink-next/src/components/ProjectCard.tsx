"use client";

/**
 * VertexLink — ProjectCard Component
 *
 * Le cœur visuel de la page Réalisations.
 * Chaque carte expose le projet comme un module d'ingénierie :
 *  - Mockup wireframe animé (browser chrome réaliste)
 *  - Stack technique avec chips colorés
 *  - Score bars Lighthouse animées à l'entrée dans le viewport
 *  - Code snippet révélé au survol
 *  - Bordure lumineuse Framer Motion
 *
 * Props : Project (voir /src/data/projects.ts)
 */

import { useRef, useState } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import clsx from "clsx";
import type { Project, LighthouseScore, TechChip } from "@/data/projects";

// ─────────────────────────────────────────────────────────
//  Sub-component : BrowserChrome
// ─────────────────────────────────────────────────────────
function BrowserChrome({ url, score }: { url: string; score: number }) {
  const scoreColor = score >= 95
    ? "text-emerald-500 bg-emerald-50"
    : score >= 80
    ? "text-amber-500 bg-amber-50"
    : "text-red-500 bg-red-50";

  return (
    <div className="flex items-center gap-2 px-3 h-8 bg-pearl-50 border-b border-black/5 shrink-0">
      {/* Traffic lights */}
      <span className="w-2.5 h-2.5 rounded-full bg-[#ff5f57]" />
      <span className="w-2.5 h-2.5 rounded-full bg-[#febc2e]" />
      <span className="w-2.5 h-2.5 rounded-full bg-[#28c840]" />
      {/* URL bar */}
      <div className="flex-1 mx-2 px-2 py-0.5 rounded bg-black/5 font-fira text-[10px] text-ink-3 truncate">
        {url}
      </div>
      {/* Lighthouse score badge */}
      <span className={clsx("font-fira text-[10px] font-semibold px-2 py-0.5 rounded", scoreColor)}>
        {score}
      </span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────
//  Sub-component : WireframeMockup
//  Simule une interface réelle en wireframe coloré
// ─────────────────────────────────────────────────────────
function WireframeMockup({ theme }: { theme: Project["mockupTheme"] }) {
  const accentAlpha = {
    blue:   "rgba(37,99,235,",
    violet: "rgba(124,58,237,",
    cyan:   "rgba(6,182,212,",
    amber:  "rgba(245,158,11,",
  }[theme];

  return (
    <div className="flex-1 bg-pearl-200 overflow-hidden flex flex-col">
      {/* Hero section wireframe */}
      <div
        className="px-4 pt-4 pb-3 shrink-0"
        style={{ background: `linear-gradient(180deg, ${accentAlpha}0.06) 0%, transparent 100%)` }}
      >
        <div className="h-4 rounded mb-2" style={{ background: `${accentAlpha}0.18)`, width: "62%" }} />
        <div className="h-2.5 rounded bg-black/8 mb-1.5" style={{ width: "80%" }} />
        <div className="h-2 rounded bg-black/6" style={{ width: "50%" }} />
        <div className="flex gap-2 mt-3">
          <div className="h-2.5 rounded-full px-3" style={{ background: `${accentAlpha}0.22)`, width: "28%" }} />
          <div className="h-2.5 rounded-full bg-black/8" style={{ width: "20%" }} />
        </div>
      </div>

      {/* Cards grid wireframe */}
      <div className="flex-1 grid grid-cols-3 gap-2 p-3">
        {[0, 1, 2].map((i) => (
          <div key={i} className="bg-white/60 rounded-lg border border-black/5 p-2 flex flex-col gap-1.5">
            <div className="h-2 rounded" style={{ background: `${accentAlpha}${i === 0 ? "0.22" : "0.10"})` }} />
            <div className="h-1.5 rounded bg-black/6" />
            <div className="h-1.5 rounded bg-black/5" style={{ width: "70%" }} />
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────
//  Sub-component : TechChipBadge
// ─────────────────────────────────────────────────────────
function TechChipBadge({ chip }: { chip: TechChip }) {
  const styles = {
    blue:    "border-blue/ring text-blue bg-blue/glow",
    violet:  "border-violet/ring text-violet bg-violet/glow",
    cyan:    "border-cyan/20 text-cyan bg-cyan/glow",
    neutral: "border-black/10 text-ink-2 bg-pearl-200",
  };

  return (
    <span
      className={clsx(
        "font-fira text-[10px] px-2 py-0.5 rounded-md border transition-all duration-200",
        styles[chip.variant]
      )}
    >
      {chip.label}
    </span>
  );
}

// ─────────────────────────────────────────────────────────
//  Sub-component : ScoreBar
// ─────────────────────────────────────────────────────────
function ScoreBar({ score, animate }: { score: LighthouseScore; animate: boolean }) {
  // Normalise la valeur en % pour la barre
  const pct = score.unit === "%"
    ? Math.min((score.value / 15) * 100, 100)   // conv. rate : max 15 %
    : score.unit === "s"
    ? Math.max(100 - score.value * 50, 10)       // TTI : inversé
    : score.value;                                // direct 0-100

  const color = pct >= 90
    ? "from-emerald-400 to-emerald-500"
    : pct >= 70
    ? "from-amber-400 to-amber-500"
    : "from-blue to-violet";

  return (
    <div className="flex flex-col gap-1">
      <div className="flex justify-between items-baseline">
        <span className="font-fira text-[9px] text-ink-3 uppercase tracking-wider">{score.label}</span>
        <span className={clsx(
          "font-fira text-xs font-semibold",
          pct >= 90 ? "text-emerald-500" : pct >= 70 ? "text-amber-500" : "text-blue"
        )}>
          {score.value}{score.unit ?? ""}
        </span>
      </div>
      <div className="h-0.5 bg-pearl-300 rounded-full overflow-hidden">
        <motion.div
          className={clsx("h-full rounded-full bg-gradient-to-r", color)}
          initial={{ scaleX: 0 }}
          animate={{ scaleX: animate ? pct / 100 : 0 }}
          transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1], delay: 0.15 }}
          style={{ transformOrigin: "left" }}
        />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────
//  Sub-component : CodeSnippetOverlay
//  Révélé au survol — slide-up depuis le bas
// ─────────────────────────────────────────────────────────
function CodeSnippetOverlay({ lines }: { lines: string[] }) {
  return (
    <motion.div
      className="absolute inset-x-0 bottom-0 bg-[rgba(13,15,26,0.93)] backdrop-blur-sm p-3 border-t border-white/10"
      initial={{ y: "100%" }}
      animate={{ y: 0 }}
      exit={{ y: "100%" }}
      transition={{ duration: 0.38, ease: [0.16, 1, 0.3, 1] }}
    >
      <div className="space-y-0.5">
        {lines.map((line, i) => (
          <div key={i} className="flex gap-3 font-fira text-[10px] leading-relaxed">
            <span className="text-white/20 select-none w-4 shrink-0">{i + 1}</span>
            <span dangerouslySetInnerHTML={{ __html: line }} />
          </div>
        ))}
      </div>
    </motion.div>
  );
}

// ─────────────────────────────────────────────────────────
//  MAIN — ProjectCard
// ─────────────────────────────────────────────────────────
interface ProjectCardProps {
  project: Project;
  index: number;
}

export function ProjectCard({ project, index }: ProjectCardProps) {
  const ref     = useRef<HTMLElement>(null);
  const inView  = useInView(ref, { once: true, margin: "-60px" });
  const [hovered, setHovered] = useState(false);

  // Luminous border color par accent
  const borderGlow = {
    blue:   "hover:shadow-blue-glow hover:border-blue/ring",
    violet: "hover:shadow-vi-glow hover:border-violet/ring",
    cyan:   "hover:border-cyan/20",
  }[project.accentColor];

  // Score Lighthouse principal (performance)
  const mainScore = project.scores.find(s => s.type === "perf")?.value ?? 0;

  return (
    <motion.article
      ref={ref}
      // ── Framer Motion — entrée staggerée ──
      initial={{ opacity: 0, y: 36 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{
        duration: 0.75,
        ease: [0.16, 1, 0.3, 1],
        delay: index * 0.12,
      }}
      // ── Hover lift ──
      whileHover={{ y: -6, transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] } }}
      className={clsx(
        "relative flex flex-col overflow-hidden rounded-2xl",
        "bg-white border border-black/8",
        "shadow-card transition-all duration-300 cursor-none",
        borderGlow,
      )}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      aria-label={`Projet ${project.title}`}
    >
      {/* ── Luminous background glow on hover ── */}
      <motion.div
        className="absolute inset-0 rounded-2xl pointer-events-none"
        style={{
          background: project.accentColor === "blue"
            ? "radial-gradient(ellipse at 50% 0%, rgba(37,99,235,.08), transparent 70%)"
            : project.accentColor === "violet"
            ? "radial-gradient(ellipse at 50% 0%, rgba(124,58,237,.07), transparent 70%)"
            : "radial-gradient(ellipse at 50% 0%, rgba(6,182,212,.07), transparent 70%)",
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: hovered ? 1 : 0 }}
        transition={{ duration: 0.4 }}
      />

      {/* ── Scan line animation au survol ── */}
      {hovered && (
        <div
          className="absolute top-0 left-0 right-0 h-px z-10 pointer-events-none"
          style={{ background: "linear-gradient(90deg, transparent, var(--blue), transparent)", animation: "scan 1.8s ease-in-out" }}
        />
      )}

      {/* ══════════════════════════════
          VISUAL — Browser mockup
      ══════════════════════════════ */}
      <div className="relative overflow-hidden" style={{ aspectRatio: "16/8" }}>
        <BrowserChrome url={project.url} score={mainScore} />

        <div className="absolute inset-0 top-8 flex flex-col overflow-hidden">
          <WireframeMockup theme={project.mockupTheme} />
        </div>

        {/* Code snippet overlay — révélé au hover */}
        <div className="absolute inset-0 top-8 overflow-hidden pointer-events-none">
          <AnimatePresence>
            {hovered && <CodeSnippetOverlay lines={project.codeSnippet} />}
          </AnimatePresence>
        </div>
      </div>

      {/* ══════════════════════════════
          BODY — Informations projet
      ══════════════════════════════ */}
      <div className="flex flex-col flex-1 p-6 gap-4 relative z-1">

        {/* ── Eyebrow : numéro + catégorie ── */}
        <div className="flex items-center gap-3">
          <span className="font-fira text-[10px] text-ink-3 px-2 py-0.5 rounded bg-pearl-200 border border-black/6">
            {project.number}
          </span>
          <span className="font-fira text-[10px] uppercase tracking-widest text-ink-3">
            {project.categoryLabel} · {project.year}
          </span>
        </div>

        {/* ── Titre projet ── */}
        <div>
          <h2 className="font-syne font-bold text-xl tracking-tight text-ink leading-none mb-1.5 transition-colors duration-200 group-hover:text-blue">
            {project.title}
          </h2>
          <p className="font-fira text-[10px] text-ink-3">{project.client}</p>
        </div>

        {/* ── Description ── */}
        <p className="font-dm text-[13px] font-light text-ink-2 leading-relaxed">
          {project.excerpt}
        </p>

        {/* ── Stack technique ── */}
        <div className="space-y-2">
          <p className="font-fira text-[9px] text-ink-3 uppercase tracking-widest flex items-center gap-1.5">
            <span className="text-cyan opacity-80">//</span> stack
          </p>
          <div className="flex flex-wrap gap-1.5">
            {project.stack.map((chip) => (
              <TechChipBadge key={chip.label} chip={chip} />
            ))}
          </div>
        </div>

        {/* ── Scores Lighthouse ── */}
        <div className="grid grid-cols-2 gap-x-5 gap-y-3 pt-4 border-t border-black/6">
          {project.scores.map((score) => (
            <ScoreBar key={score.label} score={score} animate={inView} />
          ))}
        </div>

        {/* ── Footer : lien + année ── */}
        <div className="flex items-center justify-between pt-2 mt-auto border-t border-black/5">
          <span className="font-fira text-[10px] text-ink-4">{project.year}</span>
          <motion.a
            href={`/realisations/${project.id}`}
            className={clsx(
              "flex items-center gap-1.5 font-syne font-semibold text-[11px]",
              "px-3 py-1.5 rounded-lg border transition-all duration-200",
              project.accentColor === "blue"
                ? "text-blue border-blue/ring bg-blue/glow hover:bg-blue hover:text-white"
                : project.accentColor === "violet"
                ? "text-violet border-violet/ring bg-violet/glow hover:bg-violet hover:text-white"
                : "text-cyan border-cyan/20 bg-cyan/glow hover:bg-cyan hover:text-white"
            )}
            whileHover={{ x: 2 }}
            transition={{ duration: 0.2 }}
          >
            Voir le projet
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <path d="M1 6h10M6 1l5 5-5 5" stroke="currentColor" strokeWidth="1.5"
                    strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </motion.a>
        </div>
      </div>
    </motion.article>
  );
}
