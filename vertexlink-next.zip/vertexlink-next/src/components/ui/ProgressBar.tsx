"use client";

/**
 * VertexLink — UI Micro-components
 *  - CustomCursor : curseur desktop avec anneaux animés
 *  - ProgressBar : barre de scroll en haut de page
 */

import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useSpring } from "framer-motion";

// ─────────────────────────────────────────────────────────
//  CustomCursor
// ─────────────────────────────────────────────────────────
export function CustomCursor() {
  const dotRef  = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const [hovered, setHovered] = useState(false);
  const [onText,  setOnText]  = useState(false);

  useEffect(() => {
    // Pas de curseur sur mobile
    if (window.matchMedia("(pointer: coarse)").matches) return;

    let mx = 0, my = 0, rx = 0, ry = 0;
    let raf: number;

    const onMove = (e: MouseEvent) => {
      mx = e.clientX;
      my = e.clientY;
      if (dotRef.current) {
        dotRef.current.style.left = `${mx}px`;
        dotRef.current.style.top  = `${my}px`;
      }
    };

    const lerp = () => {
      rx += (mx - rx) * 0.11;
      ry += (my - ry) * 0.11;
      if (ringRef.current) {
        ringRef.current.style.left = `${rx}px`;
        ringRef.current.style.top  = `${ry}px`;
      }
      raf = requestAnimationFrame(lerp);
    };

    window.addEventListener("mousemove", onMove);
    raf = requestAnimationFrame(lerp);

    // Hover detection
    const interactives = () => document.querySelectorAll("a, button, .pcard, [role=button]");
    const textEls      = () => document.querySelectorAll("h1, h2, h3, p");

    const addListeners = () => {
      interactives().forEach(el => {
        el.addEventListener("mouseenter", () => setHovered(true));
        el.addEventListener("mouseleave", () => setHovered(false));
      });
      textEls().forEach(el => {
        el.addEventListener("mouseenter", () => setOnText(true));
        el.addEventListener("mouseleave", () => setOnText(false));
      });
    };

    addListeners();

    return () => {
      window.removeEventListener("mousemove", onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <>
      {/* Dot */}
      <div
        ref={dotRef}
        className="fixed pointer-events-none z-[9999] -translate-x-1/2 -translate-y-1/2"
        style={{ width: 5, height: 5, background: "#2563eb", borderRadius: "50%",
                 boxShadow: "0 0 6px rgba(37,99,235,.5)", transition: "background .2s" }}
      />
      {/* Ring */}
      <div
        ref={ringRef}
        className="fixed pointer-events-none z-[9998] -translate-x-1/2 -translate-y-1/2"
        style={{
          width:         hovered ? 48 : onText ? 60 : 28,
          height:        hovered ? 48 : onText ? 18 : 28,
          borderRadius:  onText ? 4 : "50%",
          border:        `1.5px solid ${hovered ? "#2563eb" : "rgba(37,99,235,.35)"}`,
          background:    hovered ? "rgba(37,99,235,.05)" : "transparent",
          transition:    "width .35s cubic-bezier(.16,1,.3,1), height .35s cubic-bezier(.16,1,.3,1), border-color .2s, background .2s, border-radius .3s",
        }}
      />
    </>
  );
}

// ─────────────────────────────────────────────────────────
//  ProgressBar
// ─────────────────────────────────────────────────────────
export function ProgressBar() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 180, damping: 30 });

  return (
    <motion.div
      style={{
        scaleX,
        position: "fixed", top: 0, left: 0, right: 0,
        height: 2, zIndex: 9999, transformOrigin: "left",
        background: "linear-gradient(90deg, #2563eb, #7c3aed)",
        boxShadow: "0 0 8px rgba(37,99,235,.45)",
      }}
    />
  );
}
