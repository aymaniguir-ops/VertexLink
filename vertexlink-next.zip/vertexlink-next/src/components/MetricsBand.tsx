"use client";

/**
 * VertexLink — MetricsBand Component
 *
 * Bandeau de métriques agence avec :
 *  - Compteurs animés (count-up via Framer Motion)
 *  - Labels en Fira Code monospace
 *  - Séparateurs verticaux subtils
 */

import { useRef } from "react";
import { motion, useInView } from "framer-motion";

const METRICS = [
  { value: "100",    label: "Perf. Lighthouse", code: "lighthouse.perf",  unit: "" },
  { value: "A+",     label: "SEO Score",         code: "seo.grade",        unit: "" },
  { value: "<14",    label: "Jours livraison",   code: "delivery.days",    unit: "j" },
  { value: "0",      label: "Templates utilisés",code: "templates.count",  unit: "" },
  { value: "100%",   label: "Code sur mesure",   code: "code.handcrafted", unit: "" },
] as const;

export function MetricsBand() {
  const ref    = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
      className="border-y border-black/6 bg-white"
    >
      <div className="max-w-screen-xl mx-auto px-10 flex divide-x divide-black/5">
        {METRICS.map(({ value, label, code }, i) => (
          <motion.div
            key={code}
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1], delay: 0.1 + i * 0.08 }}
            className="flex-1 flex flex-col items-center text-center py-6 px-4"
          >
            {/* Big value */}
            <span className="font-syne font-extrabold text-3xl tracking-tight leading-none gradient-text mb-1">
              {value}
            </span>
            {/* Label */}
            <span className="font-dm text-[12px] text-ink-2 mb-1">{label}</span>
            {/* Code annotation */}
            <span className="font-fira text-[9px] text-cyan opacity-60">{code}</span>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
