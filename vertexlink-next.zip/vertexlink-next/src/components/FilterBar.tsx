"use client";

/**
 * VertexLink — FilterBar Component
 *
 * Barre de filtres avec :
 *  - Framer Motion layoutId pour la "pill" animée (shared layout)
 *  - Compteur de projets visible mis à jour
 *  - Esthétique code (préfixe "filter:", chips monospace)
 */

import { motion } from "framer-motion";
import clsx from "clsx";
import { FILTER_CATEGORIES } from "@/data/projects";

interface FilterBarProps {
  active: string;
  count: number;
  onChange: (value: string) => void;
}

export function FilterBar({ active, count, onChange }: FilterBarProps) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      {/* Label style code */}
      <span className="font-fira text-[10px] text-ink-3 flex items-center gap-1.5 mr-1">
        <span className="text-cyan opacity-70">//</span>
        <span>filter</span>
      </span>

      {/* Filter pills */}
      <div className="flex flex-wrap gap-1.5" role="group" aria-label="Filtrer les projets">
        {FILTER_CATEGORIES.map(({ value, label }) => {
          const isActive = active === value;
          return (
            <button
              key={value}
              onClick={() => onChange(value)}
              className={clsx(
                "relative font-fira text-[11px] px-4 py-1.5 rounded-full",
                "border transition-colors duration-200 cursor-none outline-none",
                isActive
                  ? "text-blue border-transparent"
                  : "text-ink-3 border-black/10 bg-white hover:border-blue/ring hover:text-blue"
              )}
              aria-pressed={isActive}
            >
              {/* Animated background pill */}
              {isActive && (
                <motion.span
                  layoutId="filter-pill"
                  className="absolute inset-0 rounded-full bg-blue/glow border border-blue/ring"
                  transition={{ type: "spring", stiffness: 420, damping: 36 }}
                />
              )}
              <span className="relative z-10">{label}</span>
            </button>
          );
        })}
      </div>

      {/* Project count */}
      <motion.div
        key={count}
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 1, y: 0 }}
        className="ml-auto font-fira text-[10px] text-ink-3 border border-black/8 bg-white rounded-full px-3 py-1 flex items-center gap-2"
      >
        <span className="w-1.5 h-1.5 rounded-full bg-blue animate-pulse-dot" />
        {count} {count > 1 ? "projets" : "projet"}
      </motion.div>
    </div>
  );
}
