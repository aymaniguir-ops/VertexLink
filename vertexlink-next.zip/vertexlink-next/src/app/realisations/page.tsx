"use client";

/**
 * ──────────────────────────────────────────────────────────────────
 *  VertexLink — Page Réalisations
 *  /src/app/realisations/page.tsx
 *
 *  Architecture :
 *   1. PageHero         — Titre massif Syne 800 + parallaxe scroll
 *   2. MetricsBand      — 5 métriques agence avec count-up animé
 *   3. FilterBar        — Filtres animés (Framer Motion layout pill)
 *   4. CodeBreadcrumb   — Fil d'ariane style éditeur de code
 *   5. ProjectsGrid     — Grille asymétrique 12 colonnes
 *   6. CtaBand          — Bandeau final conversion
 *   7. Footer           — Footer minimaliste
 *
 *  Animations Framer Motion :
 *   - Entrée staggerée des ProjectCards (index * 120ms delay)
 *   - AnimatePresence sur le filtre (exit smooth des cartes)
 *   - Parallaxe sur le titre hero (useScroll + useTransform)
 *   - Barre de progression au scroll (useSpring)
 *   - Scan line CSS sur hover des cartes
 *   - Score bars avec scaleX animé à l'entrée viewport
 *
 * ──────────────────────────────────────────────────────────────────
 */

import { useState, useMemo } from "react";
import { motion, AnimatePresence, useScroll, useTransform } from "framer-motion";
import Link from "next/link";
import type { Metadata } from "next";

import { Navbar }       from "@/components/Navbar";
import { MetricsBand }  from "@/components/MetricsBand";
import { FilterBar }    from "@/components/FilterBar";
import { ProjectCard }  from "@/components/ProjectCard";
import { PROJECTS }     from "@/data/projects";

// ── SEO Metadata ──
// (Dans Next.js App Router, metadata ne peut pas être dans un Client Component.
//  Déplacer dans un layout.tsx ou un Server Component wrapper en production.)
// export const metadata: Metadata = { title: "Réalisations — VertexLink" };

// ─────────────────────────────────────────────────────────
//  Page Component
// ─────────────────────────────────────────────────────────
export default function RealisationsPage() {
  const [activeFilter, setActiveFilter] = useState("all");

  // ── Filtrage des projets ──
  const filteredProjects = useMemo(() =>
    activeFilter === "all"
      ? PROJECTS
      : PROJECTS.filter(p => p.category === activeFilter),
    [activeFilter]
  );

  // ── Parallaxe title ──
  const { scrollY } = useScroll();
  const titleY   = useTransform(scrollY, [0, 400], [0,  60]);
  const titleOp  = useTransform(scrollY, [0, 320], [1, 0]);

  return (
    <>
      {/* ── Fixed UI ── */}
      <Navbar />

      <main className="min-h-screen pt-[60px] relative">

        {/* ════════════════════════════════════
            1. PAGE HERO
        ════════════════════════════════════ */}
        <section className="relative overflow-hidden px-10 pt-20 pb-16 max-w-screen-xl mx-auto">

          {/* Gradient mesh background */}
          <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
            <div className="absolute -top-32 -right-32 w-[600px] h-[600px] rounded-full opacity-25"
                 style={{ background: "radial-gradient(circle, rgba(37,99,235,.12), transparent 70%)", filter: "blur(60px)" }} />
            <div className="absolute top-1/2 -left-20 w-[400px] h-[400px] rounded-full opacity-20"
                 style={{ background: "radial-gradient(circle, rgba(124,58,237,.10), transparent 70%)", filter: "blur(50px)" }} />
          </div>

          <div className="relative z-10 flex items-end justify-between gap-10 flex-wrap">
            {/* Left — Title block */}
            <div>
              {/* Code eyebrow */}
              <motion.p
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1], delay: 0.05 }}
                className="flex items-center gap-2.5 font-fira text-[11px] text-blue mb-4"
              >
                <span className="h-px w-6 bg-blue/50 inline-block" />
                {`// pages/realisations.tsx`}
              </motion.p>

              {/* Mega title with parallax */}
              <div className="overflow-hidden">
                <motion.h1
                  style={{ y: titleY, opacity: titleOp }}
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
                  className="font-syne font-extrabold leading-[.86] tracking-tight"
                  style={{
                    fontSize: "clamp(3.5rem, 8vw, 7rem)",
                    // @ts-ignore — inline style for mixed motion + css
                    y: titleY, opacity: titleOp,
                  }}
                >
                  <span className="block text-ink">Nos</span>
                  <span className="block gradient-text">Réalisations.</span>
                </motion.h1>
              </div>

              {/* Subtitle */}
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: 0.25 }}
                className="font-dm font-light text-ink-2 text-base leading-relaxed max-w-lg mt-5"
              >
                Chaque projet est une solution d'ingénierie sur mesure.
                Design pixel-perfect, code propre, performances mesurées.
              </motion.p>
            </div>

            {/* Right — Category chips */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1], delay: 0.35 }}
              className="flex flex-col gap-2"
            >
              {[
                { dot: "bg-blue",   label: "Sites vitrines"  },
                { dot: "bg-violet", label: "Landing pages"   },
                { dot: "bg-cyan",   label: "SaaS & Apps"     },
                { dot: "bg-emerald",label: "Refonte & Audit" },
              ].map(({ dot, label }) => (
                <div key={label}
                     className="flex items-center gap-2.5 font-fira text-[11px] text-ink-3 border border-black/8 bg-white rounded-lg px-3 py-2">
                  <span className={`w-1.5 h-1.5 rounded-full ${dot}`} />
                  {label}
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* ════════════════════════════════════
            2. METRICS BAND
        ════════════════════════════════════ */}
        <MetricsBand />

        {/* ════════════════════════════════════
            3. FILTER BAR
        ════════════════════════════════════ */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.55 }}
          className="max-w-screen-xl mx-auto px-10 py-6"
        >
          <FilterBar
            active={activeFilter}
            count={filteredProjects.length}
            onChange={setActiveFilter}
          />
        </motion.div>

        {/* ════════════════════════════════════
            4. CODE BREADCRUMB
        ════════════════════════════════════ */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4, delay: 0.6 }}
          className="max-w-screen-xl mx-auto px-10 py-3 border-y border-black/5 bg-white/60 backdrop-blur-xs flex items-center gap-2 font-fira text-[10px] text-ink-3"
        >
          {/* File path */}
          {["vertexlink", "src", "pages", "realisations"].map((part, i, arr) => (
            <span key={part} className="flex items-center gap-2">
              <span className={part === "realisations" ? "text-blue" : ""}>{part}</span>
              {i < arr.length - 1 && <span className="opacity-30">/</span>}
            </span>
          ))}
          {/* Live count badge */}
          <AnimatePresence mode="wait">
            <motion.span
              key={filteredProjects.length}
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.85 }}
              className="ml-auto font-fira text-[10px] text-blue border border-blue/ring bg-blue/glow rounded-full px-2.5 py-0.5"
            >
              {filteredProjects.length} {filteredProjects.length > 1 ? "projets" : "projet"}
            </motion.span>
          </AnimatePresence>
        </motion.div>

        {/* ════════════════════════════════════
            5. PROJECTS GRID — Grille asymétrique
        ════════════════════════════════════ */}
        <section
          className="max-w-screen-xl mx-auto px-10 py-12"
          aria-label="Liste des projets"
        >
          {/*
           * Grille 12 colonnes.
           * Layout asymétrique :
           *   Ligne 1 : Hero (7 col) + Medium (5 col)
           *   Ligne 2 : Full width (12 col)
           *   Ligne 3 : Half (6 col) + Half (6 col)
           *
           * AnimatePresence gère les entrées/sorties sur filtre.
           */}
          <div className="grid grid-cols-12 gap-5">
            <AnimatePresence mode="popLayout">
              {filteredProjects.map((project, index) => {
                // Calcul des colonnes selon la taille du projet
                const colSpan = {
                  hero:     "col-span-12 lg:col-span-7",
                  wide:     "col-span-12 lg:col-span-5",
                  full:     "col-span-12",
                  tall:     "col-span-12 lg:col-span-6",
                  standard: "col-span-12 md:col-span-6 lg:col-span-6",
                }[project.size];

                return (
                  <motion.div
                    key={project.id}
                    layout
                    initial={{ opacity: 0, scale: 0.97 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.96, transition: { duration: 0.2 } }}
                    transition={{
                      layout:   { type: "spring", stiffness: 350, damping: 35 },
                      duration: 0.45,
                      ease: [0.16, 1, 0.3, 1],
                    }}
                    className={colSpan}
                  >
                    <ProjectCard project={project} index={index} />
                  </motion.div>
                );
              })}
            </AnimatePresence>

            {/* Empty state */}
            {filteredProjects.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                className="col-span-12 py-24 flex flex-col items-center gap-4 text-center"
              >
                <span className="font-fira text-[11px] text-ink-3">
                  // Aucun projet dans cette catégorie
                </span>
                <button
                  onClick={() => setActiveFilter("all")}
                  className="font-syne font-semibold text-[12px] text-blue border border-blue/ring bg-blue/glow px-4 py-2 rounded-lg hover:bg-blue hover:text-white transition-all"
                >
                  Voir tous les projets
                </button>
              </motion.div>
            )}
          </div>
        </section>

        {/* ════════════════════════════════════
            6. CTA BAND — Conversion finale
        ════════════════════════════════════ */}
        <CtaBand />

        {/* ════════════════════════════════════
            7. FOOTER
        ════════════════════════════════════ */}
        <PageFooter />
      </main>
    </>
  );
}

// ─────────────────────────────────────────────────────────
//  CtaBand — Bandeau CTA en bas de page
// ─────────────────────────────────────────────────────────
function CtaBand() {
  return (
    <section className="relative overflow-hidden border-t border-black/6 bg-white">
      {/* Background orbs */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        <div className="absolute inset-0"
             style={{ background: "radial-gradient(ellipse 60% 70% at 50% 50%, rgba(37,99,235,.05), transparent 70%)" }} />
        {/* Corner brackets */}
        <div className="absolute top-10 left-10 w-8 h-8 border-t-2 border-l-2 border-blue/20" />
        <div className="absolute bottom-10 right-10 w-8 h-8 border-b-2 border-r-2 border-violet/20" />
      </div>

      <div className="relative max-w-screen-xl mx-auto px-10 py-28 text-center">
        {/* Eyebrow */}
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.5 }}
          className="font-fira text-[11px] text-ink-3 flex items-center justify-center gap-2 mb-5"
        >
          <span className="text-cyan opacity-70">//</span>
          Prêt à construire ?
        </motion.p>

        {/* Big headline */}
        <motion.h2
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.08 }}
          className="font-syne font-extrabold tracking-tight leading-[.88] mb-10"
          style={{ fontSize: "clamp(3rem, 7vw, 6rem)" }}
        >
          <span className="text-ink block">Votre site.</span>
          <span className="gradient-text block">Votre machine</span>
          <span className="text-ink block">à clients.</span>
        </motion.h2>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
          className="flex items-center justify-center gap-4 flex-wrap"
        >
          <Link
            href="/contact"
            className="flex items-center gap-2 font-syne font-bold text-[13px] text-white px-6 py-3 rounded-xl bg-gradient-to-r from-blue to-violet shadow-[0_4px_20px_rgba(37,99,235,.3)] hover:shadow-blue-glow hover:-translate-y-0.5 transition-all duration-200 no-underline"
          >
            Réserver un appel
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M1 7h12M7 1l6 6-6 6" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </Link>
          <Link
            href="/services"
            className="flex items-center gap-2 font-fira text-[11px] text-ink-2 px-5 py-3 rounded-xl border border-black/10 bg-white hover:border-blue/ring hover:text-blue transition-all duration-200 no-underline"
          >
            Voir les offres
          </Link>
        </motion.div>

        {/* Trust micro-signal */}
        <motion.p
          initial={{ opacity: 0 }} whileInView={{ opacity: 1 }}
          viewport={{ once: true }} transition={{ delay: 0.4 }}
          className="font-fira text-[10px] text-ink-4 mt-6"
        >
          // Réponse en moins de 24h · Devis gratuit · Livraison en 14 jours
        </motion.p>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────
//  PageFooter
// ─────────────────────────────────────────────────────────
function PageFooter() {
  const COLS = [
    {
      title: "Navigation",
      links: [
        { label: "Home",         href: "/"             },
        { label: "Services",     href: "/services"     },
        { label: "Réalisations", href: "/realisations" },
        { label: "Contact",      href: "/contact"      },
      ],
    },
    {
      title: "Services",
      links: [
        { label: "Site Vitrine",  href: "/services#vitrine"  },
        { label: "Landing Page",  href: "/services#landing"  },
        { label: "Audit SEO",     href: "/services#seo"      },
        { label: "Refonte",       href: "/services#refonte"  },
      ],
    },
    {
      title: "Contact",
      links: [
        { label: "vertexlink33@gmail.com", href: "mailto:vertexlink33@gmail.com" },
        { label: "@vertexlink_",           href: "https://instagram.com/vertexlink_" },
        { label: "Réserver un appel →",    href: "/contact" },
      ],
    },
  ];

  return (
    <footer className="border-t border-black/6 bg-white pt-14 pb-8" role="contentinfo">
      <div className="max-w-screen-xl mx-auto px-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-10">
          {/* Brand */}
          <div>
            <Link href="/" className="flex items-center gap-2.5 mb-3 no-underline">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue to-violet flex items-center justify-center">
                <svg width="12" height="12" viewBox="0 0 20 20" fill="none">
                  <path d="M4 4h5v5H4zM11 4h5v5h-5zM4 11h5v5H4zM13.5 11v8M9.5 15h8"
                        stroke="white" strokeWidth="1.7" strokeLinecap="round" />
                </svg>
              </div>
              <span className="font-syne font-extrabold text-[14px] text-ink">VertexLink</span>
            </Link>
            <p className="font-dm text-[12px] text-ink-3 leading-relaxed max-w-[200px]">
              Sites web qui convertissent. Code sur mesure, performances mesurées.
            </p>
            <p className="font-fira text-[10px] text-cyan opacity-60 mt-3 leading-relaxed">
              // vertexlink33@gmail.com<br />
              // @vertexlink_ — 100% remote
            </p>
          </div>

          {/* Nav columns */}
          {COLS.map(col => (
            <div key={col.title}>
              <h4 className="font-fira text-[10px] uppercase tracking-widest text-ink-3 mb-3 flex items-center gap-1.5">
                <span className="text-blue opacity-60">//</span>
                {col.title}
              </h4>
              <ul className="space-y-2 list-none">
                {col.links.map(({ label, href }) => (
                  <li key={label}>
                    <Link
                      href={href}
                      className="font-dm text-[13px] text-ink-2 hover:text-blue transition-colors no-underline flex items-center gap-1.5 group"
                    >
                      <span className="opacity-0 group-hover:opacity-100 text-[10px] transition-opacity">→</span>
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="border-t border-black/5 pt-6 flex flex-wrap justify-between items-center gap-3 font-fira text-[10px] text-ink-4">
          <span>© 2025 VertexLink — Tous droits réservés</span>
          <div className="flex items-center gap-3">
            <span className="border border-blue/ring text-blue bg-blue/glow px-2 py-0.5 rounded">
              No WordPress. No Wix.
            </span>
            <span>Code 100% sur mesure</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
