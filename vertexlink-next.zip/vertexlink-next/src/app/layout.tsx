/**
 * VertexLink — Root Layout
 * Next.js 14 App Router
 * 
 * Responsabilités :
 *  - Injection des polices Syne + Fira Code + DM Sans
 *  - Metadata SEO globale
 *  - Barre de progression au scroll
 *  - Curseur custom desktop
 *  - Overlay noise texture
 */

import type { Metadata } from "next";
import { Syne, Fira_Code, DM_Sans } from "next/font/google";
import "./globals.css";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { CustomCursor } from "@/components/ui/CustomCursor";

// ─── Font loading — next/font pour zero layout shift ───
const syne = Syne({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-syne",
  display: "swap",
});

const firaCode = Fira_Code({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  variable: "--font-fira",
  display: "swap",
});

const dmSans = DM_Sans({
  subsets: ["latin"],
  weight: ["300", "400", "500"],
  style: ["normal", "italic"],
  variable: "--font-dm",
  display: "swap",
});

// ─── Metadata SEO ───
export const metadata: Metadata = {
  title: {
    default: "VertexLink — Agence Web Prestige",
    template: "%s — VertexLink",
  },
  description:
    "Agence web spécialisée en sites vitrines, landing pages et SEO technique. Code 100% sur mesure, Lighthouse 100, livraison en 14 jours.",
  keywords: ["agence web", "site vitrine", "landing page", "SEO", "Next.js", "développement web"],
  authors: [{ name: "VertexLink", url: "https://vertexlink.fr" }],
  creator: "VertexLink",
  openGraph: {
    type: "website",
    locale: "fr_FR",
    url: "https://vertexlink.fr",
    siteName: "VertexLink",
    title: "VertexLink — Agence Web Prestige",
    description: "Sites vitrines, Landing pages & SEO. Code sur mesure, performances mesurées.",
  },
  robots: { index: true, follow: true },
  viewport: { width: "device-width", initialScale: 1 },
};

// ─── Root Layout Component ───
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className={`${syne.variable} ${firaCode.variable} ${dmSans.variable}`}>
      <body className="font-dm bg-pearl-100 text-ink antialiased overflow-x-hidden">
        {/* Texture noise — subtile profondeur sur le fond nacré */}
        <div className="noise-overlay" aria-hidden="true" />

        {/* Barre de progression scroll */}
        <ProgressBar />

        {/* Curseur personnalisé — desktop uniquement */}
        <CustomCursor />

        {/* Contenu des pages */}
        {children}
      </body>
    </html>
  );
}
