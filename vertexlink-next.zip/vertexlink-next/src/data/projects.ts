/**
 * VertexLink — Projects Data
 * 
 * Source de vérité pour la page Réalisations.
 * Chaque projet expose sa stack technique et ses scores Lighthouse réels.
 * 
 * À terme : remplacer par un appel API CMS (Sanity, Contentful, etc.)
 */

export type ChipVariant = "blue" | "violet" | "cyan" | "neutral";
export type ProjectSize = "hero" | "wide" | "tall" | "standard";

export interface TechChip {
  label: string;
  variant: ChipVariant;
}

export interface LighthouseScore {
  label: string;
  value: number;
  unit?: string;
  /** "perf" | "seo" | "a11y" | "bp" | "conv" */
  type: "perf" | "seo" | "a11y" | "bp" | "conv";
}

export interface Project {
  id: string;
  number: string;         // "// 01"
  category: "vitrine" | "landing" | "saas" | "refonte";
  categoryLabel: string;
  size: ProjectSize;
  title: string;
  client: string;
  excerpt: string;
  url: string;
  year: number;
  accentColor: "blue" | "violet" | "cyan";
  stack: TechChip[];
  scores: LighthouseScore[];
  /** Ligne de code fictive affichée sur la carte */
  codeSnippet: string[];
  /** Couleur de fond du mockup wireframe */
  mockupTheme: "blue" | "violet" | "cyan" | "amber";
}

export const PROJECTS: Project[] = [
  // ────────────────────────────────────────
  // 01 — SocialForma  (Hero card — grande)
  // ────────────────────────────────────────
  {
    id:            "socialforma",
    number:        "// 01",
    category:      "vitrine",
    categoryLabel: "Site Vitrine",
    size:          "hero",
    title:         "SocialForma",
    client:        "Cabinet Conseil URSSAF",
    excerpt:
      "Architecture multi-pages pour un cabinet de conseil en conformité sociale. Design corporate épuré, tunnel de prise de RDV optimisé, SEO local renforcé avec Schema.org.",
    url:           "socialforma.fr",
    year:          2025,
    accentColor:   "blue",
    stack: [
      { label: "HTML5",       variant: "blue"    },
      { label: "CSS Grid",    variant: "neutral" },
      { label: "JavaScript",  variant: "violet"  },
      { label: "GSAP",        variant: "cyan"    },
      { label: "Formspree",   variant: "neutral" },
      { label: "Netlify",     variant: "blue"    },
      { label: "Schema.org",  variant: "violet"  },
    ],
    scores: [
      { label: "Performance",    value: 98,  type: "perf" },
      { label: "SEO",            value: 100, type: "seo"  },
      { label: "Accessibilité",  value: 96,  type: "a11y" },
      { label: "Best Practices", value: 100, type: "bp"   },
    ],
    codeSnippet: [
      `<span class="code-cm">// RDV tunnel — Schema.org + LocalBusiness</span>`,
      `<span class="code-kw">const</span> <span class="code-prop">schema</span> <span class="code-tx">= {</span>`,
      `&nbsp;&nbsp;<span class="code-str">"@type"</span><span class="code-tx">: </span><span class="code-str">"LocalBusiness"</span><span class="code-tx">,</span>`,
      `&nbsp;&nbsp;<span class="code-str">"sameAs"</span><span class="code-tx">: seo.canonicalUrl</span>`,
      `<span class="code-tx">}</span> <span class="code-cm">// Lighthouse: 100 🚀</span>`,
    ],
    mockupTheme: "blue",
  },

  // ────────────────────────────────────────
  // 02 — Viraly.ia  (Wide card)
  // ────────────────────────────────────────
  {
    id:            "viraly-ia",
    number:        "// 02",
    category:      "saas",
    categoryLabel: "SaaS Landing",
    size:          "wide",
    title:         "Viraly.ia",
    client:        "Contenu viral IA",
    excerpt:
      "Landing page haute conversion pour outil SaaS d'IA générative. Canvas API pour particules interactives, split A/B sur les CTA, tunnel d'inscription Stripe-ready.",
    url:           "viraly.ia",
    year:          2025,
    accentColor:   "violet",
    stack: [
      { label: "Canvas API",        variant: "violet" },
      { label: "GSAP ScrollTrigger",variant: "blue"   },
      { label: "CSS Custom Props",  variant: "neutral" },
      { label: "Stripe Elements",   variant: "violet"  },
      { label: "Netlify Functions", variant: "cyan"    },
    ],
    scores: [
      { label: "Performance", value: 97,  type: "perf" },
      { label: "SEO",         value: 98,  type: "seo"  },
      { label: "Conv. Rate",  value: 7.3, type: "conv", unit: "%" },
      { label: "TTI",         value: 1.2, type: "bp",   unit: "s" },
    ],
    codeSnippet: [
      `<span class="code-cm">// Canvas particles — 60fps garantis</span>`,
      `<span class="code-kw">const</span> <span class="code-fn">initParticles</span> <span class="code-tx">= (</span><span class="code-prop">canvas</span><span class="code-tx">) => {</span>`,
      `&nbsp;&nbsp;<span class="code-prop">ctx</span><span class="code-tx">.globalCompositeOperation =</span>`,
      `&nbsp;&nbsp;<span class="code-str">"screen"</span> <span class="code-cm">// blend lumineux</span>`,
      `<span class="code-tx">}</span>`,
    ],
    mockupTheme: "violet",
  },

  // ────────────────────────────────────────
  // 03 — Portfolio Ayman  (Standard card)
  // ────────────────────────────────────────
  {
    id:            "portfolio-ayman",
    number:        "// 03",
    category:      "vitrine",
    categoryLabel: "Portfolio",
    size:          "standard",
    title:         "Portfolio — Ingénierie éditoriale",
    client:        "Développeur web",
    excerpt:
      "Portfolio personnel multi-pages. Esthétique éditoriale nacrée, animations scroll-triggered, Playfair Display typography system, Formspree contact API.",
    url:           "aymandev.fr",
    year:          2025,
    accentColor:   "cyan",
    stack: [
      { label: "HTML5",       variant: "blue"    },
      { label: "CSS Scroll",  variant: "cyan"    },
      { label: "Formspree",   variant: "neutral" },
      { label: "Netlify",     variant: "violet"  },
    ],
    scores: [
      { label: "Performance",   value: 100, type: "perf" },
      { label: "SEO",           value: 100, type: "seo"  },
      { label: "Accessibilité", value: 98,  type: "a11y" },
    ],
    codeSnippet: [
      `<span class="code-cm">// Contact — zero backend</span>`,
      `<span class="code-kw">fetch</span><span class="code-tx">(</span><span class="code-str">"https://formspree.io/f/..."</span><span class="code-tx">, {</span>`,
      `&nbsp;&nbsp;<span class="code-prop">method</span><span class="code-tx">: </span><span class="code-str">"POST"</span><span class="code-tx">,</span>`,
      `&nbsp;&nbsp;<span class="code-prop">body</span><span class="code-tx">: JSON.stringify(formData)</span>`,
      `<span class="code-tx">})</span>`,
    ],
    mockupTheme: "cyan",
  },

  // ────────────────────────────────────────
  // 04 — ConvertNow  (Standard card)
  // ────────────────────────────────────────
  {
    id:            "convertnow",
    number:        "// 04",
    category:      "landing",
    categoryLabel: "Landing Page",
    size:          "standard",
    title:         "ConvertNow — Lead Gen B2B",
    client:        "SaaS B2B",
    excerpt:
      "Landing page lead generation pour SaaS B2B. Copywriting persuasif, Pixel Meta natif, tests A/B CTA, 7.3 % de conversion dès J+7.",
    url:           "convert-now.fr",
    year:          2025,
    accentColor:   "blue",
    stack: [
      { label: "HTML/CSS",    variant: "blue"    },
      { label: "Pixel Meta",  variant: "violet"  },
      { label: "Analytics",   variant: "neutral" },
      { label: "Formspree",   variant: "cyan"    },
      { label: "A/B Testing", variant: "neutral" },
    ],
    scores: [
      { label: "Performance", value: 99,  type: "perf" },
      { label: "SEO",         value: 97,  type: "seo"  },
      { label: "Conv. Rate",  value: 7.3, type: "conv", unit: "%" },
    ],
    codeSnippet: [
      `<span class="code-cm">// Meta Pixel — événements custom</span>`,
      `<span class="code-prop">fbq</span><span class="code-tx">(</span><span class="code-str">"track"</span><span class="code-tx">, </span><span class="code-str">"Lead"</span><span class="code-tx">, {</span>`,
      `&nbsp;&nbsp;<span class="code-prop">value</span><span class="code-tx">: </span><span class="code-num">97.0</span><span class="code-tx">,</span>`,
      `&nbsp;&nbsp;<span class="code-prop">currency</span><span class="code-tx">: </span><span class="code-str">"EUR"</span>`,
      `<span class="code-tx">})</span>`,
    ],
    mockupTheme: "blue",
  },

  // ────────────────────────────────────────
  // 05 — ArtisanLuxe  (Tall card)
  // ────────────────────────────────────────
  {
    id:            "artisanluxe",
    number:        "// 05",
    category:      "vitrine",
    categoryLabel: "Site Vitrine",
    size:          "tall",
    title:         "ArtisanLuxe — Menuiserie Prestige",
    client:        "Artisan menuisier",
    excerpt:
      "Site vitrine prestige pour menuisier haut de gamme. Portfolio réalisations, devis en ligne, SEO local Bordeaux, Core Web Vitals au vert.",
    url:           "artisan-luxe.fr",
    year:          2025,
    accentColor:   "violet",
    stack: [
      { label: "HTML5",        variant: "blue"    },
      { label: "CSS Parallax", variant: "violet"  },
      { label: "Schema Local", variant: "cyan"    },
      { label: "Netlify",      variant: "neutral" },
    ],
    scores: [
      { label: "Performance",  value: 98,  type: "perf" },
      { label: "SEO Local",    value: 100, type: "seo"  },
      { label: "Core Web",     value: 100, type: "bp"   },
    ],
    codeSnippet: [
      `<span class="code-cm">// SEO Local — Bordeaux</span>`,
      `<span class="code-str">"addressLocality"</span><span class="code-tx">: </span><span class="code-str">"Bordeaux"</span><span class="code-tx">,</span>`,
      `<span class="code-str">"areaServed"</span><span class="code-tx">: [</span><span class="code-str">"33000"</span><span class="code-tx">],</span>`,
      `<span class="code-str">"priceRange"</span><span class="code-tx">: </span><span class="code-str">"€€€"</span>`,
    ],
    mockupTheme: "amber",
  },
];

// ── Catégories pour les filtres ──
export const FILTER_CATEGORIES = [
  { value: "all",      label: "Tous les projets" },
  { value: "vitrine",  label: "Site Vitrine"     },
  { value: "landing",  label: "Landing Page"     },
  { value: "saas",     label: "SaaS / App"       },
  { value: "refonte",  label: "Refonte"          },
] as const;
