import type { Config } from "tailwindcss";

// ─────────────────────────────────────────────────────────
//  VertexLink Design Tokens
//  High-Tech Light System — Blancs nacrés + Accents électriques
// ─────────────────────────────────────────────────────────
const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      // ── Couleurs ──
      colors: {
        // Surfaces nacrées
        pearl:   { DEFAULT: "#f8f9fc", 50: "#ffffff", 100: "#f8f9fc", 200: "#f0f2f8", 300: "#e4e8f4" },
        // Textes
        ink:     { DEFAULT: "#0d0f1a", 2: "#3a3d52", 3: "#7c7f9a", 4: "#b0b3cc" },
        // Accent bleu électrique
        blue:    { DEFAULT: "#2563eb", light: "#3b82f6", glow: "rgba(37,99,235,0.15)", ring: "rgba(37,99,235,0.28)" },
        // Accent violet électrique
        violet:  { DEFAULT: "#7c3aed", light: "#8b5cf6", glow: "rgba(124,58,237,0.12)", ring: "rgba(124,58,237,0.25)" },
        // Accent cyan
        cyan:    { DEFAULT: "#06b6d4", glow: "rgba(6,182,212,0.12)" },
        // Succès
        emerald: { DEFAULT: "#10b981" },
      },

      // ── Typographie ──
      fontFamily: {
        syne:  ["var(--font-syne)", "sans-serif"],
        fira:  ["var(--font-fira)", "monospace"],
        dm:    ["var(--font-dm)", "sans-serif"],
      },

      // ── Ombres prestige ──
      boxShadow: {
        "card":       "0 1px 3px rgba(13,15,26,.05), 0 4px 16px rgba(13,15,26,.07)",
        "card-hover": "0 8px 40px rgba(13,15,26,.10), 0 2px 8px rgba(13,15,26,.05)",
        "blue-glow":  "0 0 0 3px rgba(37,99,235,.18), 0 8px 32px rgba(37,99,235,.12)",
        "vi-glow":    "0 0 0 3px rgba(124,58,237,.15), 0 8px 32px rgba(124,58,237,.10)",
        "score":      "0 2px 12px rgba(37,99,235,.18)",
      },

      // ── Animations custom ──
      keyframes: {
        "fade-up": {
          "0%":   { opacity: "0", transform: "translateY(24px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "fade-in": {
          "0%":   { opacity: "0" },
          "100%": { opacity: "1" },
        },
        "scan": {
          "0%":   { transform: "translateX(-100%)" },
          "100%": { transform: "translateX(400%)" },
        },
        "pulse-dot": {
          "0%, 100%": { opacity: "1", transform: "scale(1)" },
          "50%":      { opacity: "0.4", transform: "scale(0.8)" },
        },
        "shimmer": {
          "0%":   { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "count-up": {
          "0%":   { transform: "translateY(100%)", opacity: "0" },
          "100%": { transform: "translateY(0)",    opacity: "1" },
        },
      },
      animation: {
        "fade-up":    "fade-up .7s cubic-bezier(.16,1,.3,1) both",
        "fade-in":    "fade-in .5s ease both",
        "scan":       "scan 2.4s ease-in-out infinite",
        "pulse-dot":  "pulse-dot 2s ease-in-out infinite",
        "shimmer":    "shimmer 2.4s linear infinite",
        "count-up":   "count-up .5s cubic-bezier(.16,1,.3,1) both",
      },

      // ── Border radius ──
      borderRadius: { "2xl": "16px", "3xl": "24px" },

      // ── Backdrop blur ──
      backdropBlur: { "xs": "4px" },
    },
  },
  plugins: [],
};

export default config;
